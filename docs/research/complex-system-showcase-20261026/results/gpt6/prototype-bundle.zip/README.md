# 静态设计原型

解压后，用浏览器打开 `prototype/index.html`。三个候选可点击切换；组件、证据与下一步可展开。`prototype/transfer.html` 是另一系统的迁移演练。

页面不需要安装、构建、账户或联网运行。主动点击一手来源链接时会联网。网页底部“完整样例与证据索引”会打开同包 Markdown 文件；浏览器可能下载它，可用文本/Markdown 阅读器查看。

这是 2026-10-26 的 gpt6 独立设计候选，不连接生产系统，不运行 Delivery Assurance。GitHub 中有完整设计决定、视觉截图、来源和验收记录：

https://github.com/YuukiAS/AI_Research_Toolkit/tree/research/complex-system-showcase-20261026-gpt6/docs/research/complex-system-showcase-20261026/results/gpt6
